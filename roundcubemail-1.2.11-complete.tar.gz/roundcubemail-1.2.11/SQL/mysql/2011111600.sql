-- Updates from version 0.7-beta

ALTER TABLE `session` CHANGE `sess_id` `sess_id` varchar(128) NOT NULL;
